<?php
//Database credentials
define('SERVER','localhost');
define('HOST','id19735886_hamed');// id19735886_hamed
define('PASSWD','k|r(6)4O=uZ{<g%>');//k|r(6)4O=uZ{<g%>
define('DB', 'id19735886_shoppn');
?>