<?php
//connect to database class
require("../settings/db_class.php");

/**
*General class to handle all functions 
*/
/**
 *@author David Sampah
 * 
 */

class general_class extends db_connection
{
	//--ADD--//
	public function add_controller($a,$b){
		//write  query
		// execute
		$sql= 'rr';
		return db_query($sql);

	}

	//--SELECT--//



	//--UPDATE--//



	//--DELETE--//
	

}

?>