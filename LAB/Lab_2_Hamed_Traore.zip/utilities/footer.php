 <div class="container">
      <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-4 d-flex align-items-center">
          <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
            <svg class="bi" width="30" height="24"><use xlink:href="#bootstrap"></use></svg>
          </a>
          <span class="text-muted">Hamed Traore c'23 <br>Management Information System <br> Ashesi University </span>
        </div>
    
        <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
          <li class="ms-3"><img src="images/facebook.png" alt=""><a class="text-muted" href=""><svg class="bi" width="24" height="24"><use xlink:href=""></use></svg></a></li>
          <li class="ms-3"><img src="images/twitter.png" alt=""><a class="text-muted" href=""><svg class="bi" width="24" height="24"><use xlink:href="#facebook"></use></svg></a></li>
          <li class="ms-3"><img src="images/youtube.png" alt=""><a class="text-muted" href="images/youtube.png"><svg class="bi" width="24" height="24"><use xlink:href="#facebook"></use></svg></a></li>
        </ul>
      </footer>
    </div>